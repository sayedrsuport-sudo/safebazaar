
import { Product, Order, OrderStatus, SortOption, PriceFilter } from '../types';
import { PRODUCTS } from '../constants';

export class NawaiApiService {
  private static instance: NawaiApiService;
  private constructor() {}

  static getInstance() {
    if (!this.instance) this.instance = new NawaiApiService();
    return this.instance;
  }

  private async simulateLatency(signal?: AbortSignal) {
    const latency = 400 + Math.random() * 800;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(resolve, latency);
      if (signal) {
        signal.addEventListener('abort', () => {
          clearTimeout(timeout);
          reject(new DOMException('Request aborted', 'AbortError'));
        });
      }
    });
  }

  async getProducts(
    categories: string[], 
    signal?: AbortSignal, 
    page: number = 1, 
    limit: number = 12,
    sort: SortOption = 'newest',
    searchQuery: string = '',
    priceFilter: PriceFilter = {},
    ratingFilter: number | null = null
  ): Promise<Product[]> {
    try {
      await this.simulateLatency(signal);
      
      let filtered = [...PRODUCTS];

      // فیلتر دسته‌بندی
      if (categories.length > 0) {
        filtered = filtered.filter(p => categories.includes(p.category));
      }

      // جستجوی متنی پیشرفته
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        filtered = filtered.filter(p => 
          p.name.en.toLowerCase().includes(q) || 
          p.name.fa.toLowerCase().includes(q) ||
          p.nameEn.toLowerCase().includes(q)
        );
      }

      // فیلتر قیمت
      if (priceFilter.min !== undefined) {
        filtered = filtered.filter(p => p.plans.some(pl => pl.price >= priceFilter.min!));
      }
      if (priceFilter.max !== undefined) {
        filtered = filtered.filter(p => p.plans.some(pl => pl.price <= priceFilter.max!));
      }

      // فیلتر رتبه‌بندی فروشنده
      if (ratingFilter !== null) {
        filtered = filtered.filter(p => p.seller.rating >= ratingFilter);
      }

      // مرتب‌سازی
      filtered.sort((a, b) => {
        const priceA = a.plans[0]?.price || 0;
        const priceB = b.plans[0]?.price || 0;
        
        switch(sort) {
          case 'priceAsc': return priceA - priceB;
          case 'priceDesc': return priceB - priceA;
          case 'popularity': return b.seller.trustScore - a.seller.trustScore;
          default: return b.id.localeCompare(a.id);
        }
      });
      
      return filtered.slice((page - 1) * limit, page * limit);
    } catch (err) {
      if ((err as Error).name === 'AbortError') return [];
      throw err;
    }
  }

  async createSecureIntent(productId: string): Promise<Order> {
    await this.simulateLatency();
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product) throw new Error("Product not found");

    return {
      id: `NW-${Math.random().toString(36).substring(7).toUpperCase()}`,
      productId: product.id,
      planId: product.plans[0].id,
      status: 'PENDING',
      amount: product.plans[0].price,
      currency: product.plans[0].currency,
      paymentToken: `tok_amani_${Math.random().toString(36).substring(2)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  async verifyEscrowPayment(orderId: string, token: string): Promise<{success: boolean}> {
    await this.simulateLatency();
    return { success: true };
  }
}

export const api = NawaiApiService.getInstance();
