
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getShoppingAdvice = async (userQuery: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userQuery,
      config: {
        systemInstruction: `شما 'دستیار سیف‌بازار' هستید.
        1. سیستم امانی (Amani): امنیت تراکنش در افغانستان.
        2. پرداخت: کریدت کارت، ام-پیسه، و تمامی بانک‌های افغانستان (عزیزی، پشتنی و...).
        3. لحن: حرفه‌ای و به زبان دری سلیس.`,
      },
    });
    return response.text;
  } catch (error) {
    return "خطا در ارتباط با هوش مصنوعی.";
  }
};