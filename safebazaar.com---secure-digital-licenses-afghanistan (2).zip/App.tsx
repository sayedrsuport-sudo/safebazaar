
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductCard from './components/ProductCard';
import AIAssistant from './components/AIAssistant';
import Footer from './components/Footer';
import EscrowPayment from './components/EscrowPayment';
import { PRODUCTS, SECURITY_BADGES } from './constants';

const App: React.FC = () => {
  const [activeIntent, setActiveIntent] = useState<string | null>(null);

  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafc]">
      <Navbar />
      <Hero />
      
      <section className="bg-white border-y border-slate-100 py-8">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-center gap-12 opacity-50">
          {SECURITY_BADGES.map(b => (
            <span key={b.id} className="text-[10px] font-black tracking-widest">{b.label}</span>
          ))}
        </div>
      </section>

      <main id="shop" className="max-w-7xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {PRODUCTS.map(p => (
            <ProductCard 
              key={p.id} 
              product={p} 
              onPurchase={() => setActiveIntent(p.id)} 
            />
          ))}
        </div>
      </main>

      <Footer />
      <AIAssistant />

      {activeIntent && (
        <EscrowPayment productId={activeIntent} onClose={() => setActiveIntent(null)} />
      )}
    </div>
  );
};

export default App;