
export type OrderStatus = 'PENDING' | 'PAYMENT_VERIFIED' | 'ESCROW_HOLD' | 'DELIVERED' | 'CONFIRMED' | 'CANCELLED';

export interface LocalizedString {
  fa: string;
  ps: string;
  en: string;
}

export type Language = 'fa' | 'ps' | 'en';

export interface Plan {
  id: string;
  label: LocalizedString;
  price: number;
  currency: 'AFN' | 'USDT';
  durationMonths: number;
}

export interface Seller {
  id: string;
  name: string;
  isVerified: boolean;
  kycLevel: 1 | 2 | 3;
  rating: number;
  trustScore: number;
}

export interface Product {
  id: string;
  slug: string;
  name: LocalizedString;
  nameEn: string;
  category: string;
  description: LocalizedString;
  image: string;
  features: LocalizedString[];
  plans: Plan[];
  isAutoDelivery: boolean;
  seller: Seller;
}

// Fix: Expanded Order interface to include missing properties required by NawaiApiService in services/api.ts.
export interface Order {
  id: string;
  productId: string;
  planId: string;
  status: OrderStatus;
  amount: number;
  currency: string;
  paymentToken: string;
  createdAt: string;
  updatedAt: string;
}

// Fix: Added SortOption type to resolve import errors in services/api.ts and components/SortFilter.tsx.
export type SortOption = 'newest' | 'popularity' | 'priceAsc' | 'priceDesc';

// Fix: Added PriceFilter interface to resolve import errors in services/api.ts and components/PriceSlider.tsx.
export interface PriceFilter {
  min?: number;
  max?: number;
}
