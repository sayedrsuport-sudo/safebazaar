
import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(_: Error): State {
    return { hasError: true };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // In production, this would send logs to a service like Sentry
    console.error("[Nawai Critical Error]:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6 text-center font-vazir" dir="rtl">
          <div className="max-w-md space-y-8 bg-white p-12 rounded-[3.5rem] shadow-2xl shadow-slate-200 border border-slate-100 animate-in zoom-in-95 duration-500">
            <div className="text-7xl mb-4">🛡️</div>
            <div className="space-y-4">
              <h1 className="text-3xl font-black text-slate-900 tracking-tight">سیستم متوقف شد</h1>
              <p className="text-slate-500 font-medium leading-relaxed">
                یک اختلال امنیتی یا فنی در اجرای کد رخ داده است. برای حفظ امنیت تراکنش‌ها، فرآیند متوقف شد.
              </p>
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95"
            >
              راه‌اندازی مجدد ایمن
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
