import React from 'react';
import { CATEGORIES } from '../constants';

interface MultiCategoryFilterProps {
  selected: string[];
  onChange: (categories: string[]) => void;
}

const MultiCategoryFilter: React.FC<MultiCategoryFilterProps> = ({ selected, onChange }) => {
  const toggle = (id: string) => {
    if (selected.includes(id)) {
      onChange(selected.filter(i => i !== id));
    } else {
      onChange([...selected, id]);
    }
  };

  return (
    <div className="flex items-center gap-3 bg-white/50 backdrop-blur-md p-2 rounded-[2rem] border border-white shadow-sm overflow-x-auto no-scrollbar max-w-full">
      <button 
        onClick={() => onChange([])}
        className={`px-6 py-3 rounded-2xl text-[12px] font-black transition-all ${
          selected.length === 0 
            ? 'bg-indigo-600 text-white shadow-lg' 
            : 'text-slate-500 hover:bg-white hover:text-indigo-600'
        }`}
      >
        همه
      </button>
      {CATEGORIES.map(cat => (
        <button 
          key={cat.id}
          onClick={() => toggle(cat.id)}
          className={`whitespace-nowrap px-6 py-3 rounded-2xl text-[12px] font-black transition-all flex items-center gap-3 ${
            selected.includes(cat.id)
              ? 'bg-indigo-600 text-white shadow-lg scale-105'
              : 'text-slate-500 hover:bg-white hover:text-indigo-600 border border-transparent'
          }`}
        >
          <span>{cat.icon}</span>
          {cat.title}
        </button>
      ))}
    </div>
  );
};

export default MultiCategoryFilter;