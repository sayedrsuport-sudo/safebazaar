
import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { PAYMENT_METHODS } from '../constants';

interface EscrowPaymentProps {
  productId: string;
  onClose: () => void;
}

const EscrowPayment: React.FC<EscrowPaymentProps> = ({ productId, onClose }) => {
  const { t } = useLanguage();
  const [step, setStep] = useState<'SELECT' | 'CONFIRM' | 'SUCCESS'>('SELECT');
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null);

  const renderGroup = (group: string, title: string) => (
    <div className="space-y-4 mb-8">
      <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{title}</h5>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {PAYMENT_METHODS.filter(m => m.group === group).map(method => (
          <button
            key={method.id}
            onClick={() => setSelectedMethod(method.id)}
            className={`p-4 rounded-3xl border-2 transition-all flex flex-col items-center gap-2 ${
              selectedMethod === method.id ? 'border-indigo-600 bg-indigo-50' : 'border-slate-100 bg-white'
            }`}
          >
            <span className="text-2xl">{method.logoText}</span>
            <span className="text-[10px] font-bold text-slate-600">{method.name}</span>
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/90 backdrop-blur-xl p-4">
      <div className="bg-white w-full max-w-4xl rounded-[3rem] overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]">
        <aside className="hidden lg:flex w-64 bg-slate-950 p-10 text-white flex-col justify-between">
          <div className="space-y-8">
            <div className="text-4xl">🛡️</div>
            <h3 className="text-xl font-black leading-tight">پروتکل امانی سیف‌بازار</h3>
            <p className="text-slate-400 text-xs">{t('escrowNotice')}</p>
          </div>
        </aside>

        <div className="flex-1 p-8 overflow-y-auto">
          {step === 'SELECT' ? (
            <div className="animate-in fade-in">
              <header className="flex justify-between items-center mb-10">
                <h3 className="text-2xl font-black">{t('selectPayment')}</h3>
                <button onClick={onClose} className="p-2 bg-slate-50 rounded-full">✕</button>
              </header>
              {renderGroup('global', t('paymentGroups.global'))}
              {renderGroup('mobile', t('paymentGroups.mobile'))}
              {renderGroup('bank', t('paymentGroups.bank'))}
              <button 
                disabled={!selectedMethod}
                onClick={() => setStep('CONFIRM')}
                className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black disabled:opacity-30 mt-6 shadow-xl"
              >
                تایید و ادامه
              </button>
            </div>
          ) : step === 'CONFIRM' ? (
            <div className="text-center py-10 space-y-8 animate-in slide-in-from-bottom-4">
              <div className="text-6xl">🔐</div>
              <h4 className="text-2xl font-black">در حال قفل کردن وجه در صندوق امانی...</h4>
              <p className="text-slate-500">پس از تایید نهایی لایسنس توسط شما، وجه به فروشنده منتقل می‌شود.</p>
              <button onClick={() => setStep('SUCCESS')} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black">پرداخت نهایی</button>
            </div>
          ) : (
            <div className="text-center py-10 space-y-8 animate-in zoom-in-95">
              <div className="text-6xl">✅</div>
              <h4 className="text-2xl font-black">پرداخت با موفقیت انجام شد</h4>
              <button onClick={onClose} className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black">دریافت لایسنس</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EscrowPayment;