import React from 'react';

interface RatingFilterProps {
  selected: number | null;
  onChange: (rating: number | null) => void;
}

const RatingFilter: React.FC<RatingFilterProps> = ({ selected, onChange }) => {
  return (
    <div className="flex items-center gap-2 bg-white/50 backdrop-blur-md px-5 py-2 rounded-[2rem] border border-white shadow-sm">
      <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest hidden sm:inline">اعتبار فروشنده</span>
      <div className="flex gap-1">
        {[4, 3, 2].map((r) => (
          <button
            key={r}
            onClick={() => onChange(selected === r ? null : r)}
            className={`px-3 py-2 rounded-xl text-[11px] font-black transition-all ${
              selected === r 
                ? 'bg-amber-400 text-slate-900 shadow-md scale-105' 
                : 'bg-white text-slate-400 hover:text-amber-500'
            }`}
          >
            {r}+ ★
          </button>
        ))}
      </div>
    </div>
  );
};

export default RatingFilter;