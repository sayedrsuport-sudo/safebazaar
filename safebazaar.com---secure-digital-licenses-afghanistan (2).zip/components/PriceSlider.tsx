import React from 'react';
import { PriceFilter } from '../types';

interface PriceSliderProps {
  minMax: PriceFilter;
  onChange: (filter: PriceFilter) => void;
}

const PriceSlider: React.FC<PriceSliderProps> = ({ minMax, onChange }) => {
  return (
    <div className="flex items-center gap-4 bg-white/50 backdrop-blur-md px-6 py-2 rounded-[2rem] border border-white shadow-sm">
      <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest">قیمت</span>
      <div className="flex items-center gap-2">
        <input 
          type="number"
          placeholder="حداقل"
          value={minMax.min || ''}
          onChange={(e) => onChange({ ...minMax, min: e.target.value ? Number(e.target.value) : undefined })}
          className="w-20 bg-white border border-slate-100 rounded-xl px-3 py-2 text-[12px] font-bold outline-none focus:ring-2 focus:ring-indigo-100"
        />
        <span className="text-slate-300">-</span>
        <input 
          type="number"
          placeholder="حداکثر"
          value={minMax.max || ''}
          onChange={(e) => onChange({ ...minMax, max: e.target.value ? Number(e.target.value) : undefined })}
          className="w-20 bg-white border border-slate-100 rounded-xl px-3 py-2 text-[12px] font-bold outline-none focus:ring-2 focus:ring-indigo-100"
        />
        <span className="text-[10px] text-slate-400 font-bold">AFN</span>
      </div>
    </div>
  );
};

export default PriceSlider;