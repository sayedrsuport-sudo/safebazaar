
import React, { useState } from 'react';
import { Product } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface ProductCardProps {
  product: Product;
  onPurchase: () => void;
}

/**
 * ProductCard Component - Optimized for visual precision and high-trust e-commerce.
 */
const ProductCard: React.FC<ProductCardProps> = ({ product, onPurchase }) => {
  const { language, t } = useLanguage();
  const [selectedPlanId, setSelectedPlanId] = useState(product.plans[0].id);
  const activePlan = product.plans.find(p => p.id === selectedPlanId) || product.plans[0];

  return (
    <article 
      className="group bg-white rounded-[3.5rem] overflow-hidden border border-slate-100 flex flex-col h-full relative p-4 hover:border-indigo-100 transition-all duration-700 hover:shadow-[0_40px_80px_-20px_rgba(79,70,229,0.12)] hover:-translate-y-2"
      aria-labelledby={`title-${product.id}`}
    >
      {/* Visual Header */}
      <div className="relative aspect-[16/12] overflow-hidden rounded-[2.8rem] bg-slate-50">
        <img 
          src={product.image} 
          alt={product.name[language]} 
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        
        {product.isAutoDelivery && (
          <div className="absolute top-6 left-6 bg-indigo-600 text-white text-[10px] font-black px-4 py-2 rounded-2xl shadow-2xl z-10 flex items-center gap-2 tracking-widest uppercase">
            <span className="w-1.5 h-1.5 bg-indigo-300 rounded-full animate-pulse"></span>
            {t('instantDelivery')}
          </div>
        )}
      </div>
      
      <div className="p-8 flex flex-col flex-1">
        {/* Merchant Reliability Header */}
        <div className="flex items-center justify-between mb-6 bg-slate-50/80 backdrop-blur-sm p-3 rounded-2xl border border-slate-100/50">
           <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white rounded-xl flex items-center justify-center text-sm shadow-sm border border-slate-100" aria-hidden="true">🏢</div>
              <div className="flex flex-col">
                <span className="text-[11px] font-black text-slate-900 flex items-center gap-1.5">
                  {product.seller.name}
                  {product.seller.isVerified && (
                    <svg className="w-3.5 h-3.5 text-indigo-600" fill="currentColor" viewBox="0 0 20 20" aria-label="Verified Seller">
                      <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/>
                    </svg>
                  )}
                </span>
                <span className="text-[9px] text-slate-400 font-black uppercase tracking-[0.2em]">KYC Level {product.seller.kycLevel}</span>
              </div>
           </div>
           <div className="bg-white px-2.5 py-1.5 rounded-xl border border-slate-100 shadow-sm">
              <span className="text-indigo-600 font-black text-[11px]">{product.seller.trustScore}%</span>
           </div>
        </div>

        <div className="mb-6">
          <div className="text-[10px] text-indigo-500 font-black uppercase tracking-[0.3em] mb-2">{product.nameEn}</div>
          <h3 id={`title-${product.id}`} className="text-2xl font-black text-slate-900 leading-tight">
            {product.name[language]}
          </h3>
        </div>
        
        {/* Plan Selection UI */}
        <div className="mb-6 flex flex-wrap gap-2.5" role="radiogroup" aria-label="Duration options">
          {product.plans.map((plan) => (
            <button
              key={plan.id}
              onClick={() => setSelectedPlanId(plan.id)}
              className={`px-4 py-2.5 rounded-2xl text-[11px] font-black transition-all border outline-none focus:ring-4 focus:ring-indigo-100 ${
                selectedPlanId === plan.id
                  ? 'bg-slate-900 border-slate-900 text-white shadow-xl scale-105'
                  : 'bg-white border-slate-100 text-slate-500 hover:border-indigo-300'
              }`}
              aria-checked={selectedPlanId === plan.id}
              role="radio"
            >
              {plan.label[language]}
            </button>
          ))}
        </div>

        <p className="text-[13px] text-slate-500 mb-8 line-clamp-2 leading-relaxed font-medium">
          {product.description[language]}
        </p>
        
        {/* Purchase Action Footer */}
        <div className="mt-auto pt-8 border-t border-slate-50 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Price</span>
            <div className="flex items-center gap-1.5 font-black text-slate-900">
              <span className="text-3xl tracking-tighter">{activePlan.price.toLocaleString()}</span>
              <span className="text-[11px] text-slate-400 font-black mt-1 uppercase">{activePlan.currency}</span>
            </div>
          </div>
          
          <button 
            onClick={onPurchase}
            className="bg-indigo-600 text-white px-8 py-5 rounded-[2rem] font-black text-[13px] hover:bg-slate-900 transition-all hover:scale-105 shadow-[0_20px_40px_-10px_rgba(79,70,229,0.3)] outline-none focus:ring-4 focus:ring-indigo-200 uppercase tracking-widest"
          >
            {t('securePurchase')}
          </button>
        </div>
      </div>
    </article>
  );
};

export default ProductCard;
