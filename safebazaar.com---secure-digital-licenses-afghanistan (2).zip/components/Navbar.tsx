
import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const Navbar: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();

  return (
    <nav className="fixed top-6 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="glass-navbar rounded-3xl h-16 px-6 flex justify-between items-center shadow-xl">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black">S</div>
              <span className="font-black text-xl tracking-tighter">SAFEBAZAAR</span>
            </div>
            <select 
              value={language} 
              onChange={(e) => setLanguage(e.target.value as any)}
              className="bg-transparent text-xs font-bold outline-none cursor-pointer"
            >
              <option value="fa">دری (AF)</option>
              <option value="ps">پشتو</option>
              <option value="en">English</option>
            </select>
          </div>
          <div className="flex gap-6 text-[11px] font-black text-slate-500">
            <a href="#shop">{t('shop')}</a>
            <a href="#">{t('sellerPanel')}</a>
            <button className="bg-slate-900 text-white px-5 py-2 rounded-xl">ورود</button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;