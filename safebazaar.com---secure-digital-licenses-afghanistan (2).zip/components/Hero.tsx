
import React from 'react';
import { SITE_CONFIG } from '../constants';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-28 pb-12 hero-gradient overflow-hidden">
      <div className="absolute top-1/4 -right-1/4 w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-1/4 -left-1/4 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[120px]"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-16">
          
          <div className="flex-[1.2] text-center lg:text-right space-y-10">
            <div className="inline-flex items-center gap-3 bg-white/60 backdrop-blur-xl px-6 py-3 rounded-full border border-white shadow-sm">
              <span className="flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-600"></span>
              </span>
              <span className="text-[11px] font-black text-slate-900 tracking-wider uppercase">بزرگترین پلتفرم لایسنس دیجیتال در افغانستان</span>
            </div>
            
            <div className="space-y-6">
              <h1 className="text-5xl sm:text-7xl lg:text-8xl font-black text-slate-900 leading-[1.05] tracking-tighter">
                تجربه دنیای <br/>
                <span className="gradient-text">بدون مرز</span> با {SITE_CONFIG.siteName}
              </h1>
              <p className="text-xl sm:text-2xl text-slate-500 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-medium">
                خرید امن لایسنس‌های بین‌المللی با سیستم امانی (Amani) و پرداخت محلی. نوای، همراه شما در دنیای دیجیتال.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-5 justify-center lg:justify-start">
              <a href="#shop" className="group bg-indigo-600 text-white px-12 py-5 rounded-[2rem] font-black text-xl hover:bg-slate-900 transition-all shadow-2xl shadow-indigo-100 hover:-translate-y-1 flex items-center justify-center gap-3">
                شروع خرید امن
                <svg className="w-5 h-5 group-hover:translate-x-[-4px] transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7" strokeWidth="3" strokeLinecap="round"/></svg>
              </a>
              <button className="bg-white text-slate-900 border-2 border-slate-100 px-12 py-5 rounded-[2rem] font-black text-xl hover:bg-slate-50 transition-all shadow-xl shadow-slate-200/50">
                سیستم امانی چیست؟
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-10 pt-10">
              {[
                { label: 'تراکنش امن', value: '+۱۰،۰۰۰', icon: '🛡️' },
                { label: 'فروشندگان تایید شده', value: '۱۵۰+', icon: '🏢' },
                { label: 'پشتیبانی محلی', value: '۲۴/۷', icon: '💬' }
              ].map((stat, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-lg text-xl border border-slate-100">{stat.icon}</div>
                  <div className="text-right">
                    <div className="text-lg font-black text-slate-900">{stat.value}</div>
                    <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{stat.label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex-1 w-full max-w-lg">
            <div className="relative aspect-[4/5] bg-slate-900 rounded-[4rem] overflow-hidden shadow-2xl group">
              <img 
                src="https://images.unsplash.com/photo-1620121692029-d088224efc74?auto=format&fit=crop&q=80&w=800" 
                className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-1000"
                alt="Premium Digital Services"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent"></div>
              
              <div className="absolute bottom-10 right-10 left-10 text-white space-y-4">
                <div className="text-3xl font-black leading-tight">دسترسی به بهترین‌ها <br/> همین حالا در کابل</div>
                <div className="flex items-center gap-2 text-indigo-400 font-black text-sm">
                  <span>مشاهده محصولات ویژه امروز</span>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7" strokeWidth="2.5"/></svg>
                </div>
              </div>

              {/* Verified Badge Overlay */}
              <div className="absolute top-10 right-10 bg-white/10 backdrop-blur-xl border border-white/20 p-4 rounded-3xl animate-bounce duration-[5000ms]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center text-white">✓</div>
                  <div>
                    <div className="text-[10px] font-black text-white uppercase tracking-widest">Amani Secure</div>
                    <div className="text-[9px] text-emerald-400 font-bold">Funds Locked</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
