
import React from 'react';
import { SITE_CONFIG, PAYMENT_METHODS } from '../constants';

const Footer: React.FC = () => {
  const activePayments = PAYMENT_METHODS.filter(p => p.isActive);

  return (
    <footer className="bg-slate-950 text-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="space-y-8">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-xl shadow-indigo-500/20">
                {SITE_CONFIG.siteName[0]}
              </div>
              <span className="text-3xl font-black tracking-tighter">{SITE_CONFIG.siteName.toUpperCase()}</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed font-medium">
              نوای، معتبرترین پلتفرم ارائه خدمات دیجیتال در افغانستان است. ما پلی هستیم میان شما و دنیای بی‌پایان اشتراک‌های قانونی بین‌المللی.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-black mb-8">لینک‌های مفید</h4>
            <ul className="space-y-5 text-sm text-slate-400 font-bold">
              <li><a href="#" className="hover:text-indigo-400 transition-colors">فروشگاه اشتراک‌ها</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">سوالات متداول (FAQ)</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">وبلاگ آموزشی</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors text-rose-400">همکاری در فروش</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-black mb-8">ارتباط با ما</h4>
            <ul className="space-y-5 text-sm text-slate-400 font-bold">
              <li className="flex items-center gap-3">
                <span className="text-indigo-500 text-lg">📞</span>
                {SITE_CONFIG.supportPhone}
              </li>
              <li className="flex items-center gap-3">
                <span className="text-indigo-500 text-lg">✈️</span>
                {SITE_CONFIG.telegramId}
              </li>
              <li className="flex items-center gap-3">
                <span className="text-indigo-500 text-lg">📧</span>
                {SITE_CONFIG.email}
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-black mb-8">درگاه‌های پرداخت فعال</h4>
            <div className="grid grid-cols-2 gap-3">
              {activePayments.map(payment => (
                <div key={payment.id} className="group bg-slate-900/50 border border-slate-800 p-4 rounded-2xl hover:border-indigo-500/50 transition-all">
                  <div className="text-[11px] font-black text-indigo-400 mb-1">{payment.logoText}</div>
                  <div className="text-[10px] text-slate-500 font-bold group-hover:text-white transition-colors">{payment.name}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="pt-12 border-t border-slate-900 flex flex-col md:flex-row justify-between items-center gap-6 text-[11px] font-bold text-slate-500 uppercase tracking-widest">
          <p>© ۲۰۲۴ - تمامی حقوق برای وب‌سایت نوای محفوظ است.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
