
import React from 'react';
import { CATEGORIES } from '../constants';

interface CategoryFilterProps {
  selectedId: string;
  onSelect: (id: string) => void;
}

const CategoryFilter: React.FC<CategoryFilterProps> = ({ selectedId, onSelect }) => {
  return (
    <div className="flex justify-center items-center gap-4 overflow-x-auto pb-6 no-scrollbar px-4">
      <button 
        onClick={() => onSelect('all')}
        className={`whitespace-nowrap px-8 py-4 rounded-[1.25rem] text-[13px] font-black transition-all ${
          selectedId === 'all' 
            ? 'bg-indigo-600 text-white shadow-2xl shadow-indigo-200 scale-105' 
            : 'bg-white text-slate-500 border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50/30'
        }`}
      >
        همه دسته‌بندی‌ها
      </button>
      {CATEGORIES.map(cat => (
        <button 
          key={cat.id}
          onClick={() => onSelect(cat.id)}
          className={`whitespace-nowrap px-8 py-4 rounded-[1.25rem] text-[13px] font-black transition-all flex items-center gap-3 ${
            selectedId === cat.id 
              ? 'bg-indigo-600 text-white shadow-2xl shadow-indigo-200 scale-105' 
              : 'bg-white text-slate-500 border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50/30'
          }`}
        >
          <span className="text-lg">{cat.icon}</span>
          {cat.title}
        </button>
      ))}
    </div>
  );
};

export default CategoryFilter;
