
import React, { useState } from 'react';
import { getShoppingAdvice } from '../services/geminiService';

const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    const result = await getShoppingAdvice(query);
    setResponse(result || "");
    setLoading(false);
  };

  return (
    <div className="fixed bottom-10 right-10 z-[60]">
      {isOpen ? (
        <div className="bg-white w-96 rounded-[3rem] shadow-2xl border border-slate-100 flex flex-col max-h-[600px] overflow-hidden animate-in slide-in-from-bottom-10 duration-500">
          <div className="bg-slate-900 p-8 text-white flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-indigo-500 rounded-2xl flex items-center justify-center text-2xl shadow-lg shadow-indigo-500/20">🤖</div>
              <div>
                <h4 className="font-black text-lg leading-none">هوش مصنوعی سیف‌بازار</h4>
                <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest mt-1">Safebazaar AI v3.5</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-slate-500 hover:text-white">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2.5"/></svg>
            </button>
          </div>
          
          <div className="p-8 flex-1 overflow-y-auto space-y-6">
            {response ? (
              <div className="space-y-6 animate-in fade-in duration-500">
                <div className="bg-slate-50 p-6 rounded-3xl text-sm leading-relaxed text-slate-700 border border-slate-100 font-medium">
                  {response}
                </div>
                <button 
                  onClick={() => { setResponse(null); setQuery(''); }} 
                  className="w-full bg-slate-100 text-slate-600 py-4 rounded-2xl text-xs font-black hover:bg-slate-200 transition-all"
                >
                  مشاوره جدید
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <p className="text-xs text-slate-400 font-bold text-center">دستیار هوشمند سیف‌بازار برای انتخاب بهترین اشتراک به شما کمک می‌کند</p>
                <form onSubmit={handleSearch} className="space-y-4">
                  <textarea 
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="مثلاً: بهترین اکانت برای بازی پابجی در کابل چیست؟"
                    className="w-full bg-slate-50 border border-slate-100 rounded-3xl p-5 text-sm outline-none focus:ring-4 focus:ring-indigo-500/10 focus:bg-white transition-all min-h-[120px] resize-none font-medium"
                  />
                  <button 
                    disabled={loading}
                    className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black text-lg hover:bg-indigo-700 transition-all disabled:opacity-50 shadow-xl shadow-indigo-100"
                  >
                    {loading ? (
                      <span className="flex items-center justify-center gap-3">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        در حال تحلیل داده‌ها...
                      </span>
                    ) : 'ارسال پرسش'}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-slate-900 text-white px-8 py-5 rounded-[2rem] shadow-2xl hover:scale-110 transition-all flex items-center gap-4 group"
        >
          <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></div>
          <span className="font-black text-sm">مشاور هوشمند</span>
          <div className="bg-white/10 p-2 rounded-xl group-hover:bg-indigo-500 transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" strokeWidth="2.5"/></svg>
          </div>
        </button>
      )}
    </div>
  );
};

export default AIAssistant;