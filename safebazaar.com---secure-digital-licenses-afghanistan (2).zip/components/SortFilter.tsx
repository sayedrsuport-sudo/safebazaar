import React from 'react';
import { SortOption } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface SortFilterProps {
  selectedSort: SortOption;
  onSelectSort: (sort: SortOption) => void;
}

const SortFilter: React.FC<SortFilterProps> = ({ selectedSort, onSelectSort }) => {
  const { language } = useLanguage();
  
  const options: { id: SortOption; fa: string; en: string }[] = [
    { id: 'newest', fa: 'جدیدترین‌ها', en: 'Newest' },
    { id: 'popularity', fa: 'محبوب‌ترین', en: 'Most Popular' },
    { id: 'priceAsc', fa: 'ارزان‌ترین', en: 'Price: Low to High' },
    { id: 'priceDesc', fa: 'گران‌ترین', en: 'Price: High to Low' },
  ];

  return (
    <div className="flex flex-wrap justify-center items-center gap-3 bg-white/40 backdrop-blur-md p-2 rounded-[2rem] border border-white shadow-sm">
      <div className="px-4 text-[11px] font-black text-slate-400 uppercase tracking-[0.2em]">
        {language === 'en' ? 'Sort By' : 'مرتب‌سازی'}
      </div>
      {options.map((opt) => (
        <button
          key={opt.id}
          onClick={() => onSelectSort(opt.id)}
          className={`px-6 py-2.5 rounded-2xl text-[12px] font-black transition-all ${
            selectedSort === opt.id
              ? 'bg-slate-900 text-white shadow-xl scale-105'
              : 'text-slate-500 hover:bg-white hover:text-indigo-600'
          }`}
        >
          {language === 'en' ? opt.en : opt.fa}
        </button>
      ))}
    </div>
  );
};

export default SortFilter;