
import { Product } from './types';

export const SITE_CONFIG = {
  siteName: 'Safebazaar',
  supportPhone: '+93 700 000 000',
  telegramId: '@SafebazaarSupport',
  email: 'support@safebazaar.com'
};

export const I18N = {
  fa: {
    shop: 'مارکت‌پلیس',
    sellerPanel: 'فروشنده شوید',
    escrowNotice: 'سیستم امانی (Amani): وجه شما تا زمان تایید لایسنس نزد سیف‌بازار محفوظ می‌ماند.',
    securePurchase: 'خرید امن امانی',
    instantDelivery: 'تحویل آنی',
    searchPlaceholder: 'جستجوی لایسنس، بازی یا اشتراک...',
    selectPayment: 'انتخاب درگاه پرداخت',
    paymentGroups: {
      global: 'کریدت کارت و بین‌المللی',
      mobile: 'کیف پول موبایلی (ام-پیسه)',
      bank: 'بانک‌های افغانستان'
    }
  },
  en: {
    shop: 'Marketplace',
    sellerPanel: 'Become Seller',
    escrowNotice: 'Amani System: Funds are held by Safebazaar until license verification.',
    securePurchase: 'Secure Escrow Buy',
    instantDelivery: 'Instant',
    searchPlaceholder: 'Search licenses...',
    selectPayment: 'Select Payment Method',
    paymentGroups: {
      global: 'Credit Card & Global',
      mobile: 'Mobile Wallets',
      bank: 'Afghan Local Banks'
    }
  },
  ps: {
    shop: 'مارکیټ',
    sellerPanel: 'پلورونکی شئ',
    escrowNotice: 'اماني سیسټم: ستاسو پیسې به خوندي وي تر هغه چې لایسنس ترلاسه کړئ.',
    securePurchase: 'خوندي پیرود',
    instantDelivery: 'فوري تحویلي',
    searchPlaceholder: 'لایسنس لټون کړئ...',
    selectPayment: 'د تادیې طریقه غوره کړئ',
    paymentGroups: {
      global: 'کریدت کارت او نړیوال',
      mobile: 'موبایل والټ',
      bank: 'افغاني بانکونه'
    }
  }
};

export const PAYMENT_METHODS = [
  { id: 'visa', name: 'Visa / Mastercard', logoText: '💳', group: 'global', isActive: true },
  { id: 'usdt', name: 'USDT (Tether)', logoText: '₮', group: 'global', isActive: true },
  { id: 'mpaisa', name: 'M-Paisa (Roshan)', logoText: '📱', group: 'mobile', isActive: true },
  { id: 'hesabpay', name: 'HesabPay', logoText: '💸', group: 'mobile', isActive: true },
  { id: 'azizi', name: 'Azizi Bank', logoText: '🏦', group: 'bank', isActive: true },
  { id: 'pashtany', name: 'Pashtany Bank', logoText: '🏦', group: 'bank', isActive: true },
  { id: 'kabul', name: 'New Kabul Bank', logoText: '🏦', group: 'bank', isActive: true },
  { id: 'aub', name: 'Afghan United Bank', logoText: '🏦', group: 'bank', isActive: true }
];

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    slug: 'youtube-premium',
    nameEn: 'YouTube Premium',
    name: { fa: 'یوتیوب پریمیوم', ps: 'یوتیوب پریمیوم', en: 'YouTube Premium' },
    category: 'streaming',
    description: { fa: 'اشتراک ۱۲ ماهه قانونی روی ایمیل شما.', ps: 'د ۱۲ میاشتو قانوني ګډون.', en: '12-month legal subscription.' },
    image: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&q=80&w=600',
    features: [{ fa: 'بدون تبلیغات', ps: 'بې اعلاناتو', en: 'No Ads' }],
    isAutoDelivery: true,
    seller: { id: 's1', name: 'Safebazaar Admin', isVerified: true, kycLevel: 3, rating: 4.9, trustScore: 100 },
    plans: [{ id: 'pl1', label: { fa: 'یک ساله', ps: 'یو کال', en: '1 Year' }, price: 4200, currency: 'AFN', durationMonths: 12 }]
  }
];

export const CATEGORIES = [
  { id: 'streaming', title: 'استریمینگ', icon: '📺' },
  { id: 'software', title: 'نرم‌افزار', icon: '💻' },
  { id: 'gaming', title: 'گیمینگ', icon: '🎮' }
];

export const SECURITY_BADGES = [
  { id: 'amani', label: 'AMANI ESCROW PROTECTED' },
  { id: 'kyc', label: 'KYC VERIFIED SELLERS' }
];